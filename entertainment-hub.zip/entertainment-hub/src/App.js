import { Container } from '@material-ui/core';
import { Route, Routes } from 'react-router-dom';
import './App.css';
import Header from './components/Header/Header';
import SimpleBottomNavigation from './components/MainNav';
import Movies from './Pages/Movies/Movies';
import Trending from './Pages/Trending/Trending';
import Search from './Pages/Search/Search';
import Series from './Pages/Series/Series';

function App() {
  return (
    <>
      <Header/>
      <div className="app">
        <Container>
          <Routes>
            <Route exact path="/" element={ <Trending/>}/>
            <Route exact path="/movies" element={ <Movies/>}/>
            <Route exact path="/search" element={ <Search/>}/>
            <Route exact path="/series" element={ <Series/>}/>
          </Routes>
        </Container>
      </div>
      <SimpleBottomNavigation/>
    </>
  );
}

export default App;
