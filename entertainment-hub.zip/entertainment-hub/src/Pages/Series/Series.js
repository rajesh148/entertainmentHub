import React from 'react'

const Series = () => {
  return (
    <div>
      <span className="pageTitle">Series</span>
    </div>
  )
}

export default Series
