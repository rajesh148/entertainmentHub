import React from 'react'

const Movies = () => {
  return (
    <div>
      <span className="pageTitle">Movies</span>
    </div>
  )
}

export default Movies
